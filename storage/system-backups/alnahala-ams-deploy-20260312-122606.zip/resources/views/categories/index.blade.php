<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="mb-1"><?= e(__('categories.title', 'Asset Categories')) ?></h2>
        <p class="text-muted mb-0"><?= e(__('categories.desc', 'Organize inventory into consistent operational groups.')) ?></p>
    </div>
    <a href="<?= e(route('categories.create')) ?>" class="btn btn-primary"><?= e(__('categories.add', 'Add Category')) ?></a>
</div>

<div class="row g-3">
    <?php foreach ($categories as $category): ?>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0"><a href="<?= e(route('categories.show', ['id' => $category['id']])) ?>" class="text-decoration-none"><?= e($category['name']) ?></a></h5>
                        <span class="badge text-bg-light"><?= e((string) $category['count']) ?> <?= e(__('nav.assets', 'assets')) ?></span>
                    </div>
                    <p class="card-text text-muted mb-3"><?= e($category['description']) ?></p>
                    <div class="d-flex gap-2">
                        <a href="<?= e(route('categories.show', ['id' => $category['id']])) ?>" class="btn btn-sm btn-outline-secondary"><?= e(__('actions.view', 'View')) ?></a>
                        <a href="<?= e(route('categories.edit', ['id' => $category['id']])) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                        <form method="POST" action="<?= e(route('categories.destroy', ['id' => $category['id']])) ?>">
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this category?')">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
