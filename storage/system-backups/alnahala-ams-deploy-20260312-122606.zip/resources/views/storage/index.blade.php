<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1"><?= e(__('storage.title', 'Storage Inventory')) ?></h2>
        <p class="text-muted mb-0"><?= e(__('storage.desc', 'Warehouse stock levels and readiness status.')) ?></p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?= e(route('storage.index')) ?>" class="row g-3 align-items-end">
            <input type="hidden" name="route" value="/storage">
            <div class="col-md-4">
                <label for="storage_live_search" class="form-label fw-semibold"><?= e(__('reports.search', 'Search everything')) ?></label>
                <input type="text" name="q" id="storage_live_search" value="<?= e($filters['q']) ?>" class="form-control" placeholder="<?= e(__('storage.search_placeholder', 'Search asset, tag, category, branch, status...')) ?>">
            </div>
            <div class="col-md-2">
                <label for="section" class="form-label fw-semibold"><?= e(__('storage.section', 'Section')) ?></label>
                <select name="section" id="section" class="form-select">
                    <option value=""><?= e(__('storage.all_sections', 'All sections')) ?></option>
                    <option value="storage" <?= $filters['section'] === 'storage' ? 'selected' : '' ?>><?= e(__('storage.in_stock', 'In storage')) ?></option>
                    <option value="broken" <?= $filters['section'] === 'broken' ? 'selected' : '' ?>><?= e(__('storage.broken', 'Broken devices')) ?></option>
                    <option value="repair" <?= $filters['section'] === 'repair' ? 'selected' : '' ?>><?= e(__('storage.repair', 'Repair queue')) ?></option>
                    <option value="received" <?= $filters['section'] === 'received' ? 'selected' : '' ?>><?= e(__('storage.received', 'Received not deployed')) ?></option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="branch" class="form-label fw-semibold"><?= e(__('storage.branch', 'Branch')) ?></label>
                <select name="branch" id="branch" class="form-select">
                    <option value=""><?= e(__('assets.all_branches', 'All branches')) ?></option>
                    <?php foreach ($branchOptions as $branchOption): ?>
                        <option value="<?= e($branchOption) ?>" <?= $filters['branch'] === $branchOption ? 'selected' : '' ?>><?= e($branchOption) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="category" class="form-label fw-semibold"><?= e(__('storage.category', 'Category')) ?></label>
                <select name="category" id="category" class="form-select">
                    <option value=""><?= e(__('assets.all_categories', 'All categories')) ?></option>
                    <?php foreach ($categoryOptions as $categoryOption): ?>
                        <option value="<?= e($categoryOption) ?>" <?= $filters['category'] === $categoryOption ? 'selected' : '' ?>><?= e($categoryOption) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-outline-secondary flex-fill"><?= e(__('common.search', 'Search')) ?></button>
            </div>
            <div class="col-12 d-flex justify-content-end gap-2 flex-wrap">
                <?php $xlsParams = ['route' => '/storage/export', 'format' => 'xls'] + $filters; ?>
                <?php $pdfParams = ['route' => '/storage/export', 'format' => 'pdf'] + $filters; ?>
                <a id="storage-export-xls" href="<?= e(base_url() . '/index.php?' . http_build_query($xlsParams)) ?>" class="btn btn-outline-secondary btn-sm"><?= e(__('reports.export_excel', 'Export Excel')) ?></a>
                <a id="storage-export-pdf" href="<?= e(base_url() . '/index.php?' . http_build_query($pdfParams)) ?>" class="btn btn-outline-secondary btn-sm"><?= e(__('reports.export_pdf', 'Export PDF')) ?></a>
            </div>
        </form>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('storage.in_stock', 'In storage')) ?></div><div class="fs-4 fw-semibold"><?= e((string) $summary['storage_count']) ?></div></div></div></div>
    <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('storage.broken', 'Broken devices')) ?></div><div class="fs-4 fw-semibold text-danger"><?= e((string) $summary['broken_count']) ?></div></div></div></div>
    <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('storage.repair', 'Repair queue')) ?></div><div class="fs-4 fw-semibold text-warning"><?= e((string) $summary['repair_count']) ?></div></div></div></div>
    <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('storage.received', 'Received not deployed')) ?></div><div class="fs-4 fw-semibold text-info"><?= e((string) $summary['received_count']) ?></div></div></div></div>
</div>

<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0"><?= e(__('storage.in_stock', 'In storage')) ?></h5>
    </div>
    <div class="table-responsive">
        <table class="table mb-0 storage-table">
            <thead>
                <tr>
                    <th><?= e(__('storage.item', 'Item')) ?></th>
                    <th><?= e(__('storage.quantity', 'Quantity')) ?></th>
                    <th><?= e(__('common.status', 'Status')) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($storageItems !== []): ?>
                    <?php foreach ($storageItems as $item): ?>
                        <tr data-search="<?= e(strtolower(implode(' ', [$item['item'], $item['status']]))) ?>" data-section="storage" data-branch="" data-category="">
                            <td><?= e($item['item']) ?></td>
                            <td><?= e((string) $item['qty']) ?></td>
                            <td><?= e($item['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" class="text-muted"><?= e(__('storage.empty_stock', 'No assets are currently stored.')) ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0"><?= e(__('storage.broken', 'Broken devices')) ?></h5>
    </div>
    <div class="table-responsive">
        <table class="table mb-0 storage-table">
            <thead>
                <tr>
                    <th><?= e(__('storage.asset', 'Asset')) ?></th>
                    <th><?= e(__('storage.tag', 'Tag')) ?></th>
                    <th><?= e(__('storage.category', 'Category')) ?></th>
                    <th><?= e(__('storage.branch', 'Branch')) ?></th>
                    <th><?= e(__('storage.purchase_date', 'Purchase date')) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($brokenAssets !== []): ?>
                    <?php foreach ($brokenAssets as $asset): ?>
                        <tr data-search="<?= e(strtolower(implode(' ', [$asset['name'], $asset['tag'], $asset['category'], $asset['branch'], $asset['status']]))) ?>" data-section="broken" data-branch="<?= e($asset['branch']) ?>" data-category="<?= e($asset['category']) ?>">
                            <td><a href="<?= e(route('assets.show', ['id' => $asset['id']])) ?>"><?= e($asset['name']) ?></a></td>
                            <td><?= e($asset['tag']) ?></td>
                            <td><?= e($asset['category']) ?></td>
                            <td><?= e($asset['branch']) ?></td>
                            <td><?= e($asset['purchase_date']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-muted"><?= e(__('storage.empty_broken', 'No broken devices recorded.')) ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0"><?= e(__('storage.repair', 'Repair queue')) ?></h5>
    </div>
    <div class="table-responsive">
        <table class="table mb-0 storage-table">
            <thead>
                <tr>
                    <th><?= e(__('storage.asset', 'Asset')) ?></th>
                    <th><?= e(__('storage.tag', 'Tag')) ?></th>
                    <th><?= e(__('storage.category', 'Category')) ?></th>
                    <th><?= e(__('storage.branch', 'Branch')) ?></th>
                    <th><?= e(__('storage.purchase_date', 'Purchase date')) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($repairQueue !== []): ?>
                    <?php foreach ($repairQueue as $asset): ?>
                        <tr data-search="<?= e(strtolower(implode(' ', [$asset['name'], $asset['tag'], $asset['category'], $asset['branch'], $asset['status']]))) ?>" data-section="repair" data-branch="<?= e($asset['branch']) ?>" data-category="<?= e($asset['category']) ?>">
                            <td><a href="<?= e(route('assets.show', ['id' => $asset['id']])) ?>"><?= e($asset['name']) ?></a></td>
                            <td><?= e($asset['tag']) ?></td>
                            <td><?= e($asset['category']) ?></td>
                            <td><?= e($asset['branch']) ?></td>
                            <td><?= e($asset['purchase_date']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-muted"><?= e(__('storage.empty_repair', 'No devices in repair.')) ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header bg-white">
        <h5 class="mb-0"><?= e(__('storage.received', 'Received not deployed')) ?></h5>
    </div>
    <div class="table-responsive">
        <table class="table mb-0 storage-table">
            <thead>
                <tr>
                    <th><?= e(__('storage.asset', 'Asset')) ?></th>
                    <th><?= e(__('storage.tag', 'Tag')) ?></th>
                    <th><?= e(__('storage.category', 'Category')) ?></th>
                    <th><?= e(__('storage.branch', 'Branch')) ?></th>
                    <th><?= e(__('storage.purchase_date', 'Purchase date')) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($receivedAssets !== []): ?>
                    <?php foreach ($receivedAssets as $asset): ?>
                        <tr data-search="<?= e(strtolower(implode(' ', [$asset['name'], $asset['tag'], $asset['category'], $asset['branch'], $asset['status']]))) ?>" data-section="received" data-branch="<?= e($asset['branch']) ?>" data-category="<?= e($asset['category']) ?>">
                            <td><a href="<?= e(route('assets.show', ['id' => $asset['id']])) ?>"><?= e($asset['name']) ?></a></td>
                            <td><?= e($asset['tag']) ?></td>
                            <td><?= e($asset['category']) ?></td>
                            <td><?= e($asset['branch']) ?></td>
                            <td><?= e($asset['purchase_date']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-muted"><?= e(__('storage.empty_received', 'No received assets waiting for deployment.')) ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var searchInput = document.getElementById('storage_live_search');
    var sectionInput = document.getElementById('section');
    var branchInput = document.getElementById('branch');
    var categoryInput = document.getElementById('category');
    var exportXls = document.getElementById('storage-export-xls');
    var exportPdf = document.getElementById('storage-export-pdf');
    var rows = document.querySelectorAll('.storage-table tbody tr[data-search]');

    function applyStorageFilter() {
        var term = (searchInput && searchInput.value || '').toLowerCase().trim();
        var section = sectionInput ? sectionInput.value : '';
        var branch = branchInput ? branchInput.value : '';
        var category = categoryInput ? categoryInput.value : '';

        rows.forEach(function (row) {
            var show = (!term || row.dataset.search.indexOf(term) !== -1)
                && (!section || row.dataset.section === section)
                && (!branch || row.dataset.branch === branch)
                && (!category || row.dataset.category === category);
            row.style.display = show ? '' : 'none';
        });

        [exportXls, exportPdf].forEach(function (link) {
            if (!link) {
                return;
            }
            var url = new URL(link.href, window.location.origin);
            url.searchParams.set('q', searchInput ? searchInput.value : '');
            url.searchParams.set('section', section);
            url.searchParams.set('branch', branch);
            url.searchParams.set('category', category);
            link.href = url.toString();
        });
    }

    [searchInput, sectionInput, branchInput, categoryInput].forEach(function (node) {
        if (!node) {
            return;
        }
        node.addEventListener('input', applyStorageFilter);
        node.addEventListener('change', applyStorageFilter);
    });

    applyStorageFilter();
});
</script>
