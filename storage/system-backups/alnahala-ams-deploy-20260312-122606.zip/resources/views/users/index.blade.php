<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="mb-1"><?= e(__('nav.users', 'Users')) ?></h2>
        <p class="text-muted mb-0">System users, roles, and responsibility mapping.</p>
    </div>
    <a href="<?= e(route('users.create')) ?>" class="btn btn-primary"><?= e(__('actions.add', 'Add')) ?> <?= e(__('nav.users', 'Users')) ?></a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th><?= e(__('users.status', 'Status')) ?></th>
                    <th class="text-end"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= e($user['name']) ?></td>
                        <td><?= e($user['email']) ?></td>
                        <td><span class="badge text-bg-light"><?= e($user['role']) ?></span></td>
                        <td><span class="badge text-bg-<?= ($user['status'] ?? 'active') === 'active' ? 'success' : 'secondary' ?>"><?= e(($user['status'] ?? 'active') === 'active' ? __('users.active', 'Active') : __('users.inactive', 'Inactive')) ?></span></td>
                        <td class="text-end">
                            <a href="<?= e(route('users.edit', ['id' => $user['id']])) ?>" class="btn btn-sm btn-outline-primary"><?= e(__('actions.edit', 'Edit')) ?></a>
                            <form method="POST" action="<?= e(route('users.destroy', ['id' => $user['id']])) ?>" class="d-inline">
                                <input type="hidden" name="_method" value="DELETE">
                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this user?')"><?= e(__('actions.delete', 'Delete')) ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
