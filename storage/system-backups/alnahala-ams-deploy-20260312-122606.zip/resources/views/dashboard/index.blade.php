<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h1 class="mb-1"><?= e(__('nav.dashboard', 'Dashboard')) ?></h1>
        <p class="text-muted mb-0"><?= e(__('dashboard.desc', 'Live operational summary for assets, assignments, branches, and procurement.')) ?></p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(route('assets.create')) ?>" class="btn btn-primary"><?= e(__('dashboard.register_asset', 'Register Asset')) ?></a>
        <a href="<?= e(route('employees.index')) ?>" class="btn btn-outline-secondary"><?= e(__('nav.employees', 'Employees')) ?></a>
    </div>
</div>

<?php
$monthlyMax = max(array_map(static fn (array $row): int => (int) $row['total'], $charts['monthly_purchases'] ?: [['total' => 0]]));
$monthlyPoints = [];
$monthlyCount = count($charts['monthly_purchases']);
foreach ($charts['monthly_purchases'] as $index => $row) {
    $x = $monthlyCount > 1 ? (18 + (($index / ($monthlyCount - 1)) * 264)) : 150;
    $ratio = $monthlyMax > 0 ? ((int) $row['total'] / $monthlyMax) : 0;
    $y = 116 - ($ratio * 86);
    $monthlyPoints[] = number_format($x, 2, '.', '') . ',' . number_format($y, 2, '.', '');
}
$statusMax = max(array_map(static fn (array $row): int => (int) $row['total'], $charts['status_mix'] ?: [['total' => 0]]));
$branchMax = max(array_map(static fn (array $row): int => (int) $row['total'], $charts['branch_distribution'] ?: [['total' => 0]]));
?>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 bg-primary-subtle h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('dashboard.total_assets', 'Total assets')) ?></div>
                <div class="fs-2 fw-semibold"><?= e((string) $stats['total_assets']) ?></div>
                <div class="small text-muted mt-2"><?= e((string) $overview['kpis']['assigned_assets']) ?> <?= e(__('dashboard.assigned', 'assigned')) ?>, <?= e((string) $overview['kpis']['unassigned_assets']) ?> <?= e(__('dashboard.unassigned', 'unassigned')) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 bg-success-subtle h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('dashboard.active_assets', 'Active assets')) ?></div>
                <div class="fs-2 fw-semibold"><?= e((string) $stats['active_assets']) ?></div>
                <div class="small text-muted mt-2"><?= e((string) $overview['kpis']['deployed_assets']) ?> <?= e(__('dashboard.deployed', 'deployed')) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 bg-info-subtle h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('storage.in_stock', 'In storage')) ?></div>
                <div class="fs-2 fw-semibold"><?= e((string) $stats['in_storage']) ?></div>
                <div class="small text-muted mt-2"><?= e((string) $overview['kpis']['received_assets']) ?> <?= e(__('dashboard.received_waiting', 'received and waiting')) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 bg-warning-subtle h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('dashboard.need_attention', 'Need attention')) ?></div>
                <div class="fs-2 fw-semibold"><?= e((string) $stats['attention_needed']) ?></div>
                <div class="small text-muted mt-2"><?= e((string) $overview['kpis']['expiring_warranties']) ?> <?= e(__('dashboard.warranties_expiring', 'warranties expiring in 30 days')) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?= e(__('dashboard.purchase_trend', 'Purchase Trend')) ?></h5>
                <span class="text-muted small"><?= e(__('dashboard.last_six_months', 'Last 6 months')) ?></span>
            </div>
            <div class="card-body">
                <?php if ($charts['monthly_purchases'] !== []): ?>
                    <svg viewBox="0 0 300 130" class="w-100" role="img" aria-label="<?= e(__('dashboard.purchase_trend', 'Purchase Trend')) ?>">
                        <defs>
                            <linearGradient id="purchaseLineFill" x1="0" x2="0" y1="0" y2="1">
                                <stop offset="0%" stop-color="#0d6efd" stop-opacity="0.30"></stop>
                                <stop offset="100%" stop-color="#0d6efd" stop-opacity="0.02"></stop>
                            </linearGradient>
                        </defs>
                        <polyline points="<?= e(implode(' ', $monthlyPoints)) ?>" fill="none" stroke="#0d6efd" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></polyline>
                        <?php foreach ($charts['monthly_purchases'] as $index => $row): ?>
                            <?php
                            $x = $monthlyCount > 1 ? (18 + (($index / ($monthlyCount - 1)) * 264)) : 150;
                            $ratio = $monthlyMax > 0 ? ((int) $row['total'] / $monthlyMax) : 0;
                            $y = 116 - ($ratio * 86);
                            ?>
                            <circle cx="<?= e(number_format($x, 2, '.', '')) ?>" cy="<?= e(number_format($y, 2, '.', '')) ?>" r="4.5" fill="#0d6efd"></circle>
                        <?php endforeach; ?>
                    </svg>
                    <div class="d-flex justify-content-between text-muted small mt-3">
                        <?php foreach ($charts['monthly_purchases'] as $row): ?>
                            <div class="text-center">
                                <div><?= e($row['label']) ?></div>
                                <strong class="text-dark"><?= e((string) $row['total']) ?></strong>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0"><?= e(__('dashboard.no_chart_data', 'No chart data available yet.')) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.status_mix', 'Status Mix')) ?></h5>
            </div>
            <div class="card-body">
                <?php if ($charts['status_mix'] !== []): ?>
                    <?php foreach ($charts['status_mix'] as $row): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between small mb-1">
                                <span><?= e(__('status.' . $row['label'], ucfirst($row['label']))) ?></span>
                                <strong><?= e((string) $row['total']) ?></strong>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" style="width: <?= e((string) ($statusMax > 0 ? round(((int) $row['total'] / $statusMax) * 100, 2) : 0)) ?>%;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0"><?= e(__('dashboard.no_chart_data', 'No chart data available yet.')) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.branch_distribution', 'Branch Distribution')) ?></h5>
            </div>
            <div class="card-body">
                <?php if ($charts['branch_distribution'] !== []): ?>
                    <?php foreach ($charts['branch_distribution'] as $row): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between small mb-1">
                                <span><?= e($row['label']) ?></span>
                                <strong><?= e((string) $row['total']) ?></strong>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: <?= e((string) ($branchMax > 0 ? round(((int) $row['total'] / $branchMax) * 100, 2) : 0)) ?>%;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0"><?= e(__('dashboard.no_chart_data', 'No chart data available yet.')) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('nav.branches', 'Branches')) ?></div>
                <div class="fs-4 fw-semibold"><?= e((string) $overview['kpis']['total_branches']) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('dashboard.active_employees', 'Active employees')) ?></div>
                <div class="fs-4 fw-semibold"><?= e((string) $overview['kpis']['total_employees']) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('nav.categories', 'Categories')) ?></div>
                <div class="fs-4 fw-semibold"><?= e((string) $overview['kpis']['total_categories']) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-muted small"><?= e(__('dashboard.purchased_this_month', 'Purchased this month')) ?></div>
                <div class="fs-4 fw-semibold"><?= e((string) $overview['kpis']['purchased_this_month']) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.procurement_pipeline', 'Procurement Pipeline')) ?></h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span><?= e(__('stage.ordered', 'Ordered')) ?></span>
                    <strong><?= e((string) $overview['kpis']['ordered_assets']) ?></strong>
                </div>
                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span><?= e(__('stage.received', 'Received')) ?></span>
                    <strong><?= e((string) $overview['kpis']['received_assets']) ?></strong>
                </div>
                <div class="d-flex justify-content-between py-2">
                    <span><?= e(__('stage.deployed', 'Deployed')) ?></span>
                    <strong><?= e((string) $overview['kpis']['deployed_assets']) ?></strong>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.status_breakdown', 'Status Breakdown')) ?></h5>
            </div>
            <div class="card-body">
                <?php if ($overview['status_breakdown'] !== []): ?>
                    <?php foreach ($overview['status_breakdown'] as $row): ?>
                        <div class="d-flex justify-content-between py-2 border-bottom">
                            <span><?= e(__('status.' . $row['status'], ucfirst($row['status']))) ?></span>
                            <strong><?= e((string) $row['total']) ?></strong>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0"><?= e(__('dashboard.no_status_data', 'No asset status data available.')) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.top_categories', 'Top Categories')) ?></h5>
            </div>
            <div class="card-body">
                <?php if ($overview['category_breakdown'] !== []): ?>
                    <?php foreach ($overview['category_breakdown'] as $row): ?>
                        <div class="d-flex justify-content-between py-2 border-bottom">
                            <span><?= e($row['category']) ?></span>
                            <strong><?= e((string) $row['total']) ?></strong>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0"><?= e(__('dashboard.no_category_data', 'No category data available.')) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.branch_load', 'Branch Load')) ?></h5>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 align-middle">
                    <thead>
                        <tr>
                            <th><?= e(__('common.branch', 'Branch')) ?></th>
                            <th><?= e(__('nav.assets', 'Assets')) ?></th>
                            <th><?= e(__('nav.employees', 'Employees')) ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($overview['branch_load'] !== []): ?>
                            <?php foreach ($overview['branch_load'] as $row): ?>
                                <tr>
                                    <td><?= e($row['branch']) ?></td>
                                    <td><?= e((string) $row['asset_total']) ?></td>
                                    <td><?= e((string) $row['employee_total']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-muted"><?= e(__('dashboard.no_branch_data', 'No branch data available.')) ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.warranty_alerts', 'Warranty Alerts')) ?></h5>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 align-middle">
                    <thead>
                        <tr>
                            <th><?= e(__('nav.assets', 'Assets')) ?></th>
                            <th><?= e(__('common.branch', 'Branch')) ?></th>
                            <th><?= e(__('dashboard.expiry', 'Expiry')) ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($overview['warranty_alerts'] !== []): ?>
                            <?php foreach ($overview['warranty_alerts'] as $row): ?>
                                <tr>
                                    <td>
                                        <a href="<?= e(route('assets.show', ['id' => $row['id']])) ?>" class="text-decoration-none"><?= e($row['name']) ?></a>
                                        <div class="small text-muted"><?= e($row['tag']) ?></div>
                                    </td>
                                    <td><?= e($row['branch']) ?></td>
                                    <td>
                                        <?= e($row['warranty_expiry']) ?>
                                        <div class="small text-muted"><?= e((string) $row['days_left']) ?> <?= e(__('notifications.days_left', 'days left')) ?></div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-muted"><?= e(__('dashboard.no_warranty_data', 'No warranty dates available.')) ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.recent_assets', 'Recent Assets')) ?></h5>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 align-middle">
                    <thead>
                        <tr>
                            <th><?= e(__('nav.assets', 'Assets')) ?></th>
                            <th><?= e(__('common.branch', 'Branch')) ?></th>
                            <th><?= e(__('common.status', 'Status')) ?></th>
                            <th><?= e(__('assets.purchase_date', 'Purchase Date')) ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($overview['recent_assets'] !== []): ?>
                            <?php foreach ($overview['recent_assets'] as $row): ?>
                                <tr>
                                    <td>
                                        <a href="<?= e(route('assets.show', ['id' => $row['id']])) ?>" class="text-decoration-none"><?= e($row['name']) ?></a>
                                        <div class="small text-muted"><?= e($row['tag']) ?> • <?= e(__('stage.' . $row['procurement_stage'], ucfirst($row['procurement_stage']))) ?></div>
                                    </td>
                                    <td><?= e($row['branch']) ?></td>
                                    <td><?= e(__('status.' . $row['status'], ucfirst($row['status']))) ?></td>
                                    <td><?= e($row['purchase_date']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-muted"><?= e(__('dashboard.no_assets', 'No assets available.')) ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h5 class="mb-0"><?= e(__('dashboard.recent_movements', 'Recent Movements')) ?></h5>
            </div>
            <div class="table-responsive">
                <table class="table mb-0 align-middle">
                    <thead>
                        <tr>
                            <th><?= e(__('nav.assets', 'Assets')) ?></th>
                            <th><?= e(__('dashboard.from', 'From')) ?></th>
                            <th><?= e(__('dashboard.to', 'To')) ?></th>
                            <th><?= e(__('dashboard.date', 'Date')) ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recentMovements !== []): ?>
                            <?php foreach ($recentMovements as $movement): ?>
                                <tr>
                                    <td><?= e($movement['asset']) ?></td>
                                    <td><?= e($movement['from']) ?></td>
                                    <td><?= e($movement['to']) ?></td>
                                    <td><?= e($movement['date']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-muted"><?= e(__('dashboard.no_movements', 'No movement history available.')) ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
