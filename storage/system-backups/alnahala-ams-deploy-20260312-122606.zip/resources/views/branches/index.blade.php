<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="mb-1"><?= e(__('branches.title', 'Branches & Offices')) ?></h2>
        <p class="text-muted mb-0"><?= e(__('branches.desc', 'Overview of organizational locations and assigned asset counts.')) ?></p>
    </div>
    <a href="<?= e(route('branches.create')) ?>" class="btn btn-primary"><?= e(__('branches.add', 'Add Branch')) ?></a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th><?= e(__('common.name', 'Name')) ?></th>
                    <th><?= e(__('common.type', 'Type')) ?></th>
                    <th><?= e(__('common.address', 'Address')) ?></th>
                    <th><?= e(__('nav.assets', 'Assets')) ?></th>
                    <th class="text-end"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($branches as $branch): ?>
                    <tr>
                        <td><a href="<?= e(route('branches.show', ['id' => $branch['id']])) ?>" class="fw-semibold text-decoration-none"><?= e($branch['name']) ?></a></td>
                        <td><?= e($branch['type']) ?></td>
                        <td><?= e($branch['address']) ?></td>
                        <td><?= e((string) $branch['assets']) ?></td>
                        <td class="text-end">
                            <a href="<?= e(route('branches.show', ['id' => $branch['id']])) ?>" class="btn btn-sm btn-outline-secondary"><?= e(__('actions.view', 'View')) ?></a>
                            <a href="<?= e(route('branches.edit', ['id' => $branch['id']])) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <form method="POST" action="<?= e(route('branches.destroy', ['id' => $branch['id']])) ?>" class="d-inline">
                                <input type="hidden" name="_method" value="DELETE">
                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this branch?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
