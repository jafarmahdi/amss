<div class="d-flex justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h2 class="mb-1"><?= e(__('nav.spare_parts', 'Spare Parts')) ?></h2>
        <p class="text-muted mb-0"><?= e(__('spare_parts.desc', 'Track replacement stock, minimum levels, and compatibility notes.')) ?></p>
    </div>
    <a href="<?= e(route('spare-parts.create')) ?>" class="btn btn-primary"><?= e(__('spare_parts.add', 'Add Spare Part')) ?></a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('common.total', 'Total')) ?></div><div class="fs-3 fw-semibold"><?= e((string) $summary['total_items']) ?></div></div></div></div>
    <div class="col-md-4"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('spare_parts.total_quantity', 'Total Quantity')) ?></div><div class="fs-3 fw-semibold"><?= e((string) $summary['total_quantity']) ?></div></div></div></div>
    <div class="col-md-4"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e(__('spare_parts.low_stock', 'Low Stock')) ?></div><div class="fs-3 fw-semibold text-danger"><?= e((string) $summary['low_stock']) ?></div></div></div></div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th><?= e(__('common.name', 'Name')) ?></th>
                    <th><?= e(__('common.code', 'Code')) ?></th>
                    <th><?= e(__('assets.category', 'Category')) ?></th>
                    <th><?= e(__('common.location', 'Location')) ?></th>
                    <th><?= e(__('spare_parts.quantity', 'Quantity')) ?></th>
                    <th><?= e(__('spare_parts.compatible_with', 'Compatible With')) ?></th>
                    <th class="text-end"><?= e(__('common.actions', 'Actions')) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($parts !== []): ?>
                    <?php foreach ($parts as $part): ?>
                        <tr>
                            <td><span class="fw-semibold"><?= e($part['name']) ?></span><?= ($part['low_stock'] ?? false) ? ' <span class="badge text-bg-danger">' . e(__('spare_parts.low_stock', 'Low Stock')) . '</span>' : '' ?></td>
                            <td><?= e($part['part_number']) ?></td>
                            <td><?= e($part['category']) ?></td>
                            <td><?= e($part['location']) ?></td>
                            <td><?= e((string) $part['quantity']) ?> / <?= e((string) $part['min_quantity']) ?></td>
                            <td><?= e($part['compatible_with']) ?></td>
                            <td class="text-end">
                                <a href="<?= e(route('spare-parts.edit', ['id' => $part['id']])) ?>" class="btn btn-sm btn-outline-primary"><?= e(__('actions.edit', 'Edit')) ?></a>
                                <form method="POST" action="<?= e(route('spare-parts.destroy', ['id' => $part['id']])) ?>" class="d-inline">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this spare part?')"><?= e(__('actions.delete', 'Delete')) ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-muted"><?= e(__('spare_parts.empty', 'No spare parts added yet.')) ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
